import { App } from "./app.js";

const app: App = new App();
app.setup();