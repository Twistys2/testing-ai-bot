export interface CooldownData {
    /* When the cool-down was created */
    createdAt: number;
    
    /* How long the cool-down lasts */
    duration: number;
}