import { ColorResolvable, Snowflake } from "discord.js";

import { DatabaseCollectionType } from "./db/manager.js";

export interface ConfigDiscordChannel {
    /* ID of the guild */
    guild: Snowflake;

	/* ID of the forum channel */
    channel: Snowflake;
}

export interface ConfigBrandingPartner {
	/* Name of the partner */
	name: string;

	/* Description of the partner */
	description?: string;

	/* Emoji for the partner, optional */
	emoji?: string;

	/* URL to the partner's website */
	url: string;
}

export interface ConfigBranding {
	/* Color to use for most embeds */
	color: ColorResolvable;

	/* List of partners */
	partners: ConfigBrandingPartner[];
}

export interface Config {
	/* Token of the Discord bot */
	discord: {
		/* Credentials of the bot */
		token: string;
		id: Snowflake;

		/* Invite code for the support server */
		inviteCode: string;

		/* Guilds, which should have access to restricted commands */
		guilds: Snowflake[];
	};

	/* Whether metrics about usage, cool-down, guilds, users, etc. should be collected in the database */
	metrics: boolean;

	/* Whether the bot is in development mode */
	dev: boolean;

	/* Branding stuff */
	branding: ConfigBranding;

	/* How many clusters to allocate for the bot */
	clusters: number | string | "auto";
	shardsPerCluster: number;

	channels: {
		/* Where the error messages should be sent; which guild and channel */
		error: ConfigDiscordChannel;

		/* Where the moderation messages should be sent; which guild and channel */
		moderation: ConfigDiscordChannel;

		/* Where status update messages should be sent; which guild and channel */
		status: ConfigDiscordChannel;
	};

	/* OpenAI API information */
	openAI: {
		/* API key */
		key: string;
	};

	/* HuggingFace API information */
	huggingFace: {
		/* API key */
		key: "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"
	};

	/* Replicate API information */
	replicate: {
		/* API key */
		key: string;
	};

	/* top.gg API information */
	topgg: {
		/* API key */
		key: string;
	}

	/* Turing API information */
	turing: {
		/* API key */
		key: string;
		super: string;

		urls: {
			prod: string;
			dev?: string;
		}

		/* Various CAPTCHA verification keys */
		captchas: {
			turnstile: string;
		};
	}

	/* OCR.space API information */
	ocr: {
		/* API key */
		key: string;
	};

	/* Various GIF APIs */
	gif: {
		tenor: string; 
	};

	/* Stable Horde API secrets & information */
	stableHorde: {
		/* API key */
		key: string;
	};

	/* RabbitMQ configuration */
	rabbitMQ: {
		url: string;
	}

	/* General database information */
	db: {
		supabase: {
			url: string;

			key: {
				anon: string;
				service: string;
			};

			collections?: {
				[key in DatabaseCollectionType]?: string;
			};
		};

		redis: {
			url: string;
			password: string;
			port: number;
		};
	
		"discord": {
			"token": "MTIxODQ2MjM1NTY1NTIyOTUyMg.GsPeFt.k0x3pBEVXgT_Bk1JkgjrO92cmpJNOXH7ETwDqM",
			"id": "1218462355655229522",
	
			"owner": [ "1115113173117308928" ],
			"inviteCode": "Invite code to support server, e.g. turing"
		},
	
		"branding": {
			"noticeColor": "This is the color used for most embeds",
			"color": "#5765F2"
		},
	
		"noticeMetrics": "Whether metrics about usage, cool-down, guilds, users, etc. should be collected in the database",
		"metrics": true,
	
		"noticeDev": "Whether developer info should be logged",
		"dev": true,
	
		"clusters": "auto",
		"shardsPerCluster": 3,
	
		"channels": {
			"moderation": {
				"channel": "1218735303641141431",
				"guild": "1179400512144146483"
			},
	
			"error": {
				"channel": "1218735209361440788",
				"guild": "1179400512144146483"
			},
	
			"status": {
				"channel": "1218735350747365406",
				"guild": "1179400512144146483"
			}
		},
	
		"openAI": {
			"key": "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"
		},
	
		"replicate": {
			"key": "r8_LAWuVeF5ObhLgqMR2sF35uUYYAf6v6C2X8tip"
		},
	
		"ocr": {
			"key": "K82933376888957"
		},
	
		"huggingFace": {
			"key": "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"
		},
	
		"gif": {
			"tenor": "AIzaSyA8l3pbBX_QlyBf5cU-DoVPJLtPPDjU4DU"
		},
	
		"stableHorde": {
			"key": "2VSUQzTtcPv5ZbD2-Yx-Mw"
		}
	}
}
